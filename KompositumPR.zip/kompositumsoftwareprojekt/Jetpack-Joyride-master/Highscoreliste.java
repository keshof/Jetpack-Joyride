// von liste_mit_abschluss_lsg (Mebis)

public abstract class Highscoreliste{
    
    public abstract Highscoreliste getNachfolger();
    
    public abstract void informationAusgeben();
    
    public abstract Datenelement getInhalt();

    public abstract Highscoreliste hintenEinfuegen(Datenelement dNeu);
    
    public abstract Highscoreliste endeEntfernen(Datenelement d);
    
    public abstract Datenelement getEnde(Datenelement d);

    public abstract int restlaengeGeben();
    
    

}