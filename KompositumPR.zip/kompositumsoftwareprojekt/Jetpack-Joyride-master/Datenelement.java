// von liste_mit_abschluss_lsg (Mebis)

interface Datenelement{
  void informationAusgeben();
  boolean istKleinerAls(Datenelement d);
  boolean schluesselIstGleich(String s);
}